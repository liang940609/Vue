import slot from './slot'
import partial from './partial'

export default {
  slot,
  partial
}
